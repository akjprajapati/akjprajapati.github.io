---
layout: post
author: Manav Sehgal
category: theme
title: Starter Post - Twitter Embed
tags: social embeds
image: /img/embed/twitter-bird.jpg
---

You can add social media content as embeds. 

Here is an example of a Tweet announcing OpenTheme.

<blockquote class="twitter-tweet" lang="en"><p>Create Awesome Websites on GitHub for Free! <a href="http://t.co/tXj8H17vZE">http://t.co/tXj8H17vZE</a> <a href="http://t.co/2VCbLf0KrL">pic.twitter.com/2VCbLf0KrL</a></p>&mdash; Manav Sehgal (@manavsehgal) <a href="https://twitter.com/manavsehgal/status/539376525720977410">December 1, 2014</a></blockquote>
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

Tweet embed can be copied straight from Twitter embed link within a Tweet.
